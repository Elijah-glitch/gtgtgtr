from django.urls import path

from . import views

app_name = 'help'

urlpatterns = [
    path('', views.kb_index, name='kb_index'),
    path('<slug:category>/', views.kb_category, name='kb_category'),
    path('<slug:category>/<int:entry>/', views.kb_entry, name='kb_entry'),
    path('<slug:category>/<int:entry>/feedback/', views.kb_feedback, name='kb_feedback'),
]

