---
Title: Using the VPN with Tor
TocDepth: 2
---

The main use of a VPN is to provide an encrypted connection with clean, non-interfering gateways,
but it does not provide much anonymity depending on the threat.  
While we pledge not to leak or sell your data to any business or government unless required by law,
we still have to know some information for operational purposes that could be taken by force by a motivated attacker or government agency.

There are a few ways to combine our VPN with Tor for additional anonymity and privacy.  
This page will go over the methods and their uses and issues.

[TOC]


### a. Tor through the VPN

Much better for anonymity, but requires careful use of end-to-end encryption (HTTPS, SSH, ...)

#### Pros:

- it will hide your usage of the Tor network to your ISP or local network (and show a regular VPN or TLS connection instead).
- it will be as anonymous as using Tor directly.

#### Cons:

- VPN servers can get identified and blocked.
- it uses Tor exit nodes, which are not under our control and can intercept, monitor, and alter the traffic.

#### Installation:

1. Install the VPN.
2. Install tor or the Tor Browser Bundle.
3. By using the Tor SOCKS proxy or the Tor Browser, you will effectively be using Tor over the VPN.


### b. VPN through Tor

Harder to keep anonymous but will provide a clean and secure connection even over Tor.

#### Pros:

- it will successfully bypass most firewalls and government censorships thanks to Tor (and Tor bridges).
- your connection to the VPN is anonymized.
- you replace untrusted Tor exit nodes with our servers, likely more reliable and safer.

#### Cons:

- your anonimity depends on the payment method used for the VPN.
- the bandwidth will be limited by Tor and its network.
- VPN servers aren't as anonymous as most Tor exit nodes. please don't get us into any trouble.


#### Installation:

1. We will assume using a separate host or virtual machine for Tor.  
    This configuration is implemented by Whonix and Qubes, and we recommend it for strong
    anonymity. It also greatly simplifies routing and avoids some simple failure modes.

2. Set up the VPN on the "Workstation" (your host or VM behind the Tor gateway)  
    * You will need a TCP configuration to go over Tor
    * Whonix Workstation: you will need to loosen the local firewall to be able to use a VPN:  
        `sudo iptables -I OUTPUT -j ACCEPT`  
        It shouldn't have serious security implications, providing that your physical network (or virtual network between VM)
        is properly isolated.
    * Whonix Workstation: change the default DNS server to use the VPN's server:  
        `echo "nameserver 10.99.0.20" | sudo tee /etc/resolv.conf`
    * Whonix Workstation: using the default browser will always use Tor through a proxy.
        The easiest workaround is to install and use a regular version of Firefox:  
        `sudo apt install firefox-esr`

3. Your trafic should be sent to the VPN, over Tor.
    Your current IP address as seen from a website visited on your workstation VM should be linked to the VPN.
