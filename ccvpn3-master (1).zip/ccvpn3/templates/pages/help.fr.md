---
Title: Guides
---

### Installation

<ul class="install-guides">
  <li><a href="/page/install-android"><i class="fa fa-android fa-5x"></i> Android</a></li>
  <li><a href="/page/install-windows"><i class="fa fa-windows fa-5x"></i> Windows</a></li>
  <li><a href="/page/install-gnulinux"><i class="fa fa-linux fa-5x"></i> GNU/Linux</a></li>
  <li><a href="/page/install-osx"><i class="fa fa-apple fa-5x"></i> OS X</a></li>
  <li><a href="/page/install-chromeos"><i class="fa fa-chrome fa-5x"></i> Chromebook</a></li>
</ul>

### Aide

  - [**F.A.Q.**](/kb/): Nous couvrons déjà beaucoup de questions communes dans notre F.A.Q.
  - [**Auto-Diagnostic**](/page/self-diagnosis) : Avant de demander de l'aide, vérifiez si vous trouvez la solution à votre problème ici.

### Contactez Nous

  - [**Tickets**](/tickets/): Le moyen le plus sûr et fiable de communiquer avec nous.
  - E-mail: **support at ccrypto.org** si vous ne voulez pas créer un compte ou avez un problème avec votre compte.

