---
Title: Install on Mac OS X
---

1. Download the .ovpn file you need in [your account](/account/config).

2. Download and install [TunnelBlick](https://tunnelblick.net/).

3. Import the provided .ovpn OpenVPN configuration in TunnelBlick.

4. The VPN is now ready to use within TunnelBlick.


