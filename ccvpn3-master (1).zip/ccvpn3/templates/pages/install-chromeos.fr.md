---
Title: Install on Chrome OS
---

1. Téléchargez le fichier .onc requis dans [votre compte](/account/config), en choisissant
  Chrome OS comme OS.

2. Allez sur [chrome://net-internals/](chrome://net-internals/#chromeos), partie ChromeOS, et importez le fichier téléchargé.
  Aucun message ne sera affiché, mais il devrait avoir été importé quand même.

    <img src="/static/pageimg/install_chromeos_1_arrows.png" alt="screenshot" />

3. Ouvrez les options de Chrome OS, cliquez sur Private Network (en dessous de Ethernet et Wi-Fi),
  et sélectionnez CCrypto VPN.

    <img src="/static/pageimg/install_chromeos_2.png" alt="screenshot" />

4. Cliquez ensuite sur le bouton Connect, entrez votre mot de passe, et appuyez sur Connect
  à nouveau.

    <img src="/static/pageimg/install_chromeos_3.png" alt="screenshot" />

5. Attendez quelques secondes et le VPN devrait être connecté.

    <img src="/static/pageimg/install_chromeos_4.png" alt="screenshot" />

