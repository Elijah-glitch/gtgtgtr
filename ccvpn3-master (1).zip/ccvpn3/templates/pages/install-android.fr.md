---
Title: Installation sur Android
---

1. Installez d'abord [OpenVPN pour Android d'Arne Schwabe][openvpn_android].
   C'est le client Android le mieux mis à jour et le plus sécurisé.

2. Téléchargez le fichier .ovpn dont vous avez besoin dans [votre compte](/account/config)
    et enregistrez-le quelque part.

3. Ouvrez l'application OpenVPN et importez le .ovpn téléchargé. Un nouveau
    profile sera crée.

4. *(Facultatif)* Éditez le profile et entrez votre identifiant et mot de passe
    pour qu'ils ne soient pas demandés à chaque connexion.

5. Vous pouvez maintenant vous connecter à ce profile.  
    Pendant la connexion, le log OpenVPN sera affiché. Si il y a une erreur,
    vous pouvez envoyer les informations nécessaires à *support at ccrypto.org*
    grace au menu ou en copiant le log dans un ticket.

[openvpn_android]: https://play.google.com/store/apps/details?id=de.blinkt.openvpn

