---
Title: Installation sous GNU/Linux
---

### Avec NetworkManager

1. Téléchargez et installez OpenVPN et le plugin NM avec votre gestionnaire de paquets :

    - *Debian*: `sudo apt-get install openvpn resolvconf network-manager-openvpn network-manager-openvpn-gnome`
    - *Fedora*: `sudo yum install openvpn networkmanager-openvpn`
    - *Arch Linux*: `sudo pacman -S openvpn networkmanager-openvpn`

2. Vous aurez aussi besoin de notre certificat: <https://vpn.ccrypto.org/ca.crt>  
    Vous pouvez le télécharger avec un clic droit ou une autre méthode.
    It sera nécessaire pour se connecter, placez-le en lieu sûr.

3. Créez une nouvelle connection de type *OpenVPN*.

4. Copiez la configuration du VPN:

    - **Onglet VPN**
        - **Passerelle**: `gw.random.204vpn.net` pour un serveur aléatoire, ou choisissez un pays dans [la liste](/status).
        - **Type**: *Mot de passe*
        - **Nom d'utilisateur** and **Mot de passe**: Les même que sur ce site.
        - **CA certificate**: Le fichier ca.crt téléchargé dans l'étape précédente.

    - **Onglet VPN, dans Avancé/Advanced, puis l'onglet Général**
        - **Uiliser un port de passerelle personnalisé**: *Coché* et sur *1196*.
        - **Utiliser une connexion TCP**: *Décoché* pour utiliser le mode UDP plus rapide.
            Si la connexion ne passe pas, vous pouvez essayer en TCP sur le port *443*.
        - **Randomiser les hôtes distants**: *Coché*.
        - **IPv6 tun link**: *Coché* sauf si vous constatez des problèmes liés à l'IPv6.

3. Enregistrez la connexion et connectez-vous.


### Avec systemd (Arch, Fedora 16 ou plus, Debian 8 ou plus, ...)

1. Téléchargez et installez OpenVPN avec votre gestionnaire de paquets :

    - Debian: `sudo apt-get install openvpn`
    - Fedora: `sudo yum install openvpn`
    - Arch Linux: `sudo pacman -S openvpn`

2. Téléchargez la configuration (.ovpn) dont vous avez besoin dans
    [votre compte](/account/config) et placez la dans `/etc/openvpn/` .  
    Renommez le pour avoir un .conf.
    ie: `/etc/openvpn/ccrypto.conf`

3. Démarrez le service OpenVPN :

        sudo systemctl start openvpn@ccrypto

4. *(Facultatif)* Pour qu'OpenVPN puisse se connecter au démarrage,
    créez un fichier texte quelque part avec votre identifiant et votre
    mot de passe, sur deux lignes. Ajoutez ensuite cette ligne à la fin de
    votre fichier .conf :

        auth-user-pass /path/to/the/file.txt

    Et activez le service systemd :

        systemctl enable openvpn@ccrypto

    Pour plus de sécurité, vous pouvez restreindre l'accès à ce fichier :

        sudo chown root:root /path/to/the/file.txt
        sudo chmod 600 /path/to/the/file.txt


Sans systemd (Debian avant 8.0, ...)
---------------

1. Téléchargez et installez OpenVPN avec votre gestionnaire de paquets :

    - Debian: `sudo apt-get install openvpn resolvconf`
    - Fedora: `sudo yum install openvpn`

2. Téléchargez la configuration (.ovpn) dont vous avez besoin dans
    [votre compte](/account/config) et placez la dans `/etc/openvpn/` .  
    Renommez le pour avoir un .conf.
    ie: `/etc/openvpn/ccrypto.conf`

3. Démarrez le service OpenVPN :

        sudo service openvpn start ccrypto

4. *(Facultatif)* Pour qu'OpenVPN puisse se connecter au démarrage,
    créez un fichier texte quelque part avec votre identifiant et votre
    mot de passe, sur deux lignes. Ajoutez ensuite cette ligne à la fin de
    votre fichier .conf :

        auth-user-pass /path/to/the/file.txt

    Ajoutez le nom du fichier de configuration à la liste AUTOSTART dans `/etc/default/openvpn` (vous pouvez l'ajouter à la fin):

        AUTOSTART="ccrypto"

    Pour plus de sécurité, vous pouvez restreindre l'accès à ce fichier :

        sudo chown root:root /path/to/the/file.txt
        sudo chmod 600 /path/to/the/file.txt



