---
Title: Install on GNU/Linux
---

### With NetworkManager

1. Download and install OpenVPN and the NetworkManager plugin with your package manager.

    - *Debian*: `sudo apt-get install openvpn resolvconf network-manager-openvpn network-manager-openvpn-gnome`
    - *Fedora*: `sudo yum install openvpn networkmanager-openvpn`
    - *Arch Linux*: `sudo pacman -S openvpn networkmanager-openvpn`

2. You will also need our CA certificate, available here: <https://vpn.ccrypto.org/ca.crt>  
    You can right click on that link and save the file or download it differently.
    It will be required to connect, so make sure to not delete it later.

3. Create a new connection and choose the type *OpenVPN*.

4. You will need to fill in the following VPN configuration:

    - **Tab VPN**
        - **Gateway**: `gw.random.204vpn.net` for a random server, or pick one in the [server list](/status).
        - **Type**: *Password*
        - **User name** and **Password**: The same as on this site.
        - **CA certificate**: The ca.crt file downloader in the previous step.

    - **Tab VPN, click on Advanced, then the first General tab**
        - **Use custom gateway port**: It should be *checked* and set to *1196*.
        - **Use a TCP connection**: It should be *unchecked* to use the fastest UDP mode.
            If you have issues connecting, you can try setting the port to *443* and checking this option.
        - **Randomize remote hosts**: It should be *checked*.
        - **IPv6 tun link**: It should be checked unless you get IPv6-related issues.

3. Save the new connection and connect to it.


### With systemd (Arch, Fedora 16 or later, Debian 8 or later, ...)

1. Download and install OpenVPN with your package manager.

    - Debian: `sudo apt-get install openvpn`
    - Fedora: `sudo yum install openvpn`
    - Arch Linux: `sudo pacman -S openvpn`

2. Download the .ovpn file you need in [your account](/account/config) and put
    it in `/etc/openvpn/` .  
    ie: `/etc/openvpn/ccrypto.conf`

3. Start the OpenVPN service:

        sudo systemctl start openvpn@ccrypto

4. *(Optional)* To make OpenVPN start at boot,
    create a text file anywhere and write your username and
    password inside, on two lines.  
    Then, add at the end of your ccrypto.conf file:

        auth-user-pass /path/to/the/file.txt

    And enable the systemd service :

        systemctl enable openvpn@ccrypto

    For additional security, you can make sure only root is be able to access this file:

        sudo chown root:root /path/to/the/file.txt
        sudo chmod 600 /path/to/the/file.txt



Without systemd (Debian before 8.0, ...)
---------------

1. Download and install OpenVPN with your package manager.

    - Debian: `sudo apt-get install openvpn resolvconf`
    - Fedora: `sudo yum install openvpn`

2. Download the .ovpn file you need in [your account](/account/config) and put
    it in `/etc/openvpn/` .  
    ie: `/etc/openvpn/ccrypto.conf`

3. Start the OpenVPN service:

        sudo service openvpn start ccrypto

4. *(Optional)* To make OpenVPN start at boot,
    create a text file anywhere and write your username and
    password inside, on two lines.  
    Then, add at the end of your ccrypto.conf file:

        auth-user-pass /path/to/the/file.txt

    And add the configuration file name to the AUTOSTART list in `/etc/default/openvpn` (you can add it at the end):

        AUTOSTART="ccrypto"

    For additional security, you can make sure only root is be able to access this file:

        sudo chown root:root /path/to/the/file.txt
        sudo chmod 600 /path/to/the/file.txt



