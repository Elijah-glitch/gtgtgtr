---
Title: Support
---


### Installation Guides

<ul class="install-guides">
  <li><a href="/page/install-android"><i class="fa fa-android fa-5x"></i> Android</a></li>
  <li><a href="/page/install-windows"><i class="fa fa-windows fa-5x"></i> Windows</a></li>
  <li><a href="/page/install-gnulinux"><i class="fa fa-linux fa-5x"></i> GNU/Linux</a></li>
  <li><a href="/page/install-osx"><i class="fa fa-apple fa-5x"></i> OS X</a></li>
  <li><a href="/page/install-chromeos"><i class="fa fa-chrome fa-5x"></i> Chromebook</a></li>
</ul>

### Help

  - [**Knowledge Base**](/kb/): We already cover many common questions in our knowledge base.
  - [**Self-Diagnosis**](/page/self-diagnosis): Before asking for help, check here if you find the solution to your problem.

### Contact Us

  - [**Tickets**](/tickets/): The most reliable and private way to reach us.
  - E-mail: **support at ccrypto.org** if you would like to ask a question without creating an account, or need help with your account.

