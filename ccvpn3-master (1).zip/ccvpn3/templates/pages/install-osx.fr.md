---
Title: Installation sous Mac OS X
---

1. Télécharger la configuration (.ovpn) dont vous avez besoin dans [votre compte](/account/config).

2. Téléchargez et installez [TunnelBlick](https://tunnelblick.net/).

3. Importez le fichier .ovpn dans TunnelBlick.

4. Vous pouvez utiliser le VPN avec TunnelBlick.


