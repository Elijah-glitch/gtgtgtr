DEBUG = False
SECRET_KEY = ''
ALLOWED_HOSTS = ['vpn.ccrypto.org']
# REAL_IP_HEADER_NAME = 'X-Real-Ip'
ROOT_URL = 'https://vpn.ccrypto.org/'
# Where to copy static files
STATIC_ROOT = '/home/ccvpn/public/static/'
TICKETS_SITE_NAME = 'CCrypto VPN Support'

#DATABASES = {
#    'default': {
#        'ENGINE': 'django.db.backends.postgresql_psycopg2',
#        'NAME': 'ccvpn3',
#        'USER': 'ccvpn3',
#        'PASSWORD': '',
#        'HOST': 'localhost',
#    },
#}

#LCORE = {}

EMAIL_HOST = 'localhost'
EMAIL_PORT = 25
SERVER_EMAIL = 'support@localhost'
DEFAULT_FROM_EMAIL = 'support@localhost'

PAYMENTS_CURRENCY = ('eur', '€')
PAYMENTS_BACKENDS = {}
