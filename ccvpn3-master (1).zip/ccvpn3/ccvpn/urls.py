from django.urls import path, include
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.views.generic.base import RedirectView
import django_lcore

from lambdainst import views as account_views

from . import views

urlpatterns = [
    path('admin/status', account_views.admin_status, name='admin_status'),
    path('admin/referrers', account_views.admin_ref, name='admin_ref'),
    path('admin/', admin.site.urls),
    path('vpn/', include(django_lcore.urls)),

    path('api/locations', account_views.api_locations),
    path('api/auth', django_lcore.views.api_auth),

    path('', views.index, name='index'),
    path('ca.crt', account_views.ca_crt),
    path('setlang', views.set_lang, name='set_lang'),
    path('chat', views.chat, name='chat'),
    path('page/faq', RedirectView.as_view(url='/kb/')),
    path('page/<name>', views.page, name='page'),
    path('status', account_views.status),

    path('account/forgot', auth_views.PasswordResetView.as_view(),
         {}, name='password_reset'),
    path('account/forgot_done', auth_views.PasswordResetDoneView.as_view(),
         name='password_reset_done'),
    path('account/reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('account/reset/done/', auth_views.PasswordResetCompleteView.as_view(),
         name='password_reset_complete'),

    path('tinymce/', include('tinymce.urls')),
    path('account/', include('lambdainst.urls', namespace='account')),
    path('payments/', include('payments.urls', namespace='payments')),
    path('tickets/', include('tickets.urls', namespace='tickets')),
    path('kb/', include('kb.urls', namespace='kb')),
]

