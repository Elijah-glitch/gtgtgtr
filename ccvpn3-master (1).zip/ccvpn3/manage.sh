#!/bin/sh

# sometimes cron lacks $LANG. it can cause unicode issues with python
export LANG="en_US.UTF-8"

# poetry can also be in:
# * ~/.local/bin/ (installed with pip)
export PATH="$HOME/.local/bin/:$PATH"
# * ~/.poetry/bin/ (installed with get-poetry)
export PATH="$HOME/.poetry/bin/:$PATH"

DIR="$(dirname $0)"
cd $DIR

poetry run ./manage.py $@
