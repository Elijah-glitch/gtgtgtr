CCrypto VPN 
===========

CCVPN is the software we use at CCrypto to provide our VPN.
You can see it live at https://vpn.ccrypto.org/

It handles user management, support tickets, billing and is used as a backend
for VPN authentication.  
It communicates with an external service, lambdacore, that manages VPN servers
and sessions.

**Disclaimer: this is a specialized solution that requires proprietary software to function.
This repo is a way for us to share our work freely as we don't believe keeping it secret will do any good;
feel free to base your own work on it but don't except it to be of an use as-is.**

CCrypto's commercial support *does not* include this and will not help you set it up.
Feel free to contact us about ccvpn, but with no guarantee.  
[PacketImpact](https://packetimpact.net/) however may provide you commercial support
and more services about ccvpn and lambdacore.


## Getting Started

```bash
# Install poetry
pip3 install poetry
export PATH=~/.local/bin/:$PATH  # also add that to your .profile

# Install ccvpn3
git clone https://git.ccrypto.org/ccrypto/ccvpn3.git
cd ccvpn3
poetry config settings.virtualenvs.in-project true
poetry install

cp ccvpn/local_settings.sample.py ccvpn/local_settings.py
# Edit ccvpn/local_settings.py
# See ccvpn/settings.py for all available settings and defaults

# Those need to be run on installation and updates
poetry run ./manage.py migrate
poetry run ./manage.py compilemessages
poetry run ./manage.py collectstatic

# The standard Django manage.py can be called through poetry
poetry run ./manage.py runserver
```

## Debian Deployment


```bash
# Install uwsgi and a web server, and python deps
apt install gettext git nginx uwsgi uwsgi-plugin-python3 python3-venv python3-setuptools python3-pip

# Create a new account and switch to it
adduser --disabled-login ccvpn

su - ccvpn
# As ccvpn, follow the instructions in Getting Started
# then Ctrl-D/exit back to root

cp /home/ccvpn/ccvpn3/deploy/nginx.conf /etc/nginx/sites-enabled/ccvpn3.conf
cp /etc/ccvpn/ccvpn3/deploy/uwsgi.ini /etc/uwsgi/apps-enabled/ccvpn3.ini
systemctl restart uwsgi
systemctl reload nginx
```

## CRON

Mostly for cron use, there is a `manage.sh` script that prepares
the environment and calls `manage.py` through poetry.

```cron
# Send account expiration notice e-mails
0   */6 * * * /home/ccvpn/ccvpn3/manage.sh expire_notify
# Expire old and cancelled payments
0   0   * * * /home/ccvpn/ccvpn3/manage.sh expire_payments
# [bitcoin] Check for incoming payments 
*/5 *   * * * /home/ccvpn/ccvpn3/manage.sh check_btc_payments
```
