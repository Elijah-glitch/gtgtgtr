from django.urls import path

from . import views

app_name = 'tickets'

urlpatterns = [
    path('new', views.new, name='new'),
    path('view/<id>', views.view, name='view'),
    path('', views.index, name='index'),
    path('open', views.index, dict(f='open'), name='index_open'),
    path('closed', views.index, dict(f='closed'), name='index_closed'),
    path('all_open', views.index, dict(f='open', all=True), name='index_open_all'),
    path('all_closed', views.index, dict(f='closed', all=True), name='index_closed_all'),
]

