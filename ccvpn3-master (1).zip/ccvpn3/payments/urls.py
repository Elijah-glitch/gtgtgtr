from django.conf.urls import url
from . import views

app_name = 'payments'

urlpatterns = [
    url(r'^new$', views.new),
    url(r'^view/(?P<id>[0-9]+)$', views.view, name='view'),
    url(r'^cancel/(?P<id>[0-9]+)$', views.cancel, name='cancel'),
    url(r'^cancel_subscr/(?P<id>[0-9]+)?$', views.cancel_subscr, name='cancel_subscr'),
    url(r'^return_subscr/(?P<id>[0-9]+)$', views.return_subscr, name='return_subscr'),

    url(r'^callback/paypal/(?P<id>[0-9]+)$', views.payment_callback('paypal'), name='cb_paypal'),
    url(r'^callback/coingate/(?P<id>[0-9]+)$', views.payment_callback('coingate'), name='cb_coingate'),
    url(r'^callback/stripe/(?P<id>[0-9]+)$', views.payment_callback('stripe'), name='cb_stripe'),
    url(r'^callback/coinbase/$', views.plain_callback('coinbase'), name='cb_coinbase'),
    url(r'^callback/coinpayments/(?P<id>[0-9]+)$', views.payment_callback('coinpayments'), name='cb_coinpayments'),
    url(r'^callback/paypal_subscr/(?P<id>[0-9]+)$', views.sub_callback('paypal'), name='cb_paypal_subscr'),

    url(r'^callback/stripe_hook$', views.stripe_hook, name='stripe_hook'),

    url(r'^$', views.list_payments),
]
