import json
from django.shortcuts import resolve_url
from django.contrib import admin
from django.utils.html import format_html
from django.utils.translation import ugettext_lazy as _
from django.utils.text import Truncator
from .models import Payment, Subscription, Feedback


def subscr_mark_as_cancelled(modeladmin, request, queryset):
    queryset.update(status='cancelled')
subscr_mark_as_cancelled.short_description = _("Mark as cancelled (do not actually cancel)")


def link(text, url):
    if not url:
        return text
    if not text:
        text = url
    return format_html('<a href="{}">{}</a>', url, text)

def json_format(code):
    j = json.dumps(code, indent=2)
    return format_html("<pre>{}</pre>", j)


class PaymentAdmin(admin.ModelAdmin):
    model = Payment
    list_display = ('user', 'backend', 'status', 'amount', 'paid_amount', 'created')
    list_filter = ('backend_id', 'status')

    fieldsets = (
        (None, {
            'fields': ('backend', 'user_link', 'subscription_link', 'time', 'status',
                       'status_message'),
        }),
        (_("Payment Data"), {
            'fields': ('amount_fmt', 'paid_amount_fmt',
                       'backend_extid_link', 'backend_data_fmt'),
        }),
    )

    readonly_fields = ('backend', 'user_link', 'time', 'status', 'status_message',
                       'amount_fmt', 'paid_amount_fmt', 'subscription_link',
                       'backend_extid_link', 'backend_data_fmt')
    search_fields = ('user__username', 'user__email', 'backend_extid', 'backend_data')

    def backend(self, object):
        return object.backend.backend_verbose_name

    def backend_data_fmt(self, object):
        return json_format(object.backend_data)

    def backend_extid_link(self, object):
        ext_url = object.backend.get_ext_url(object)
        return link(object.backend_extid, ext_url)

    def amount_fmt(self, object):
        return '%.2f %s' % (object.amount / 100, object.currency_name)
    amount_fmt.short_description = _("Amount")

    def paid_amount_fmt(self, object):
        return '%.2f %s' % (object.paid_amount / 100, object.currency_name)
    paid_amount_fmt.short_description = _("Paid amount")

    def user_link(self, object):
        change_url = resolve_url('admin:auth_user_change', object.user.id)
        return link(object.user.username, change_url)
    user_link.short_description = 'User'

    def subscription_link(self, object):
        change_url = resolve_url('admin:payments_subscription_change',
                                 object.subscription.id)
        return link(object.subscription.id, change_url)
    subscription_link.short_description = 'Subscription'


class SubscriptionAdmin(admin.ModelAdmin):
    model = Subscription
    list_display = ('user', 'created', 'status', 'backend', 'backend_extid')
    list_filter = ('backend_id', 'status')
    readonly_fields = ('user_link', 'backend', 'period', 'created', 'status',
                       'last_confirmed_payment', 'payments_links',
                       'backend_extid_link', 'backend_data_fmt')
    search_fields = ('user__username', 'user__email', 'backend_extid', 'backend_data')
    actions = (subscr_mark_as_cancelled,)
    fieldsets = (
        (None, {
            'fields': ('backend', 'user_link', 'period', 'payments_links', 'status',
                       'last_confirmed_payment'),
        }),
        (_("Payment Data"), {
            'fields': ('backend_extid_link', 'backend_data_fmt'),
        }),
    )

    def backend(self, object):
        return object.backend.backend_verbose_name

    def backend_data_fmt(self, object):
        return json_format(object.backend_data)

    def user_link(self, object):
        change_url = resolve_url('admin:auth_user_change', object.user.id)
        return link(object.user.id, change_url)
    user_link.short_description = 'User'

    def payments_links(self, object):
        count = Payment.objects.filter(subscription=object).count()
        payments_url = resolve_url('admin:payments_payment_changelist')
        url = "%s?subscription__id__exact=%s" % (payments_url, object.id)
        return link("%d payment(s)" % count, url)
    payments_links.short_description = 'Payments'

    def backend_extid_link(self, object):
        ext_url = object.backend.get_subscr_ext_url(object)
        return link(object.backend_extid, ext_url)
    backend_extid_link.allow_tags = True

class FeedbackAdmin(admin.ModelAdmin):
    model = Feedback
    list_display = ('user', 'created', 'short_message')
    readonly_fields = ('user', 'created', 'message', 'subscription')

    def short_message(self, obj):
        return Truncator(obj.message).chars(80)

admin.site.register(Payment, PaymentAdmin)
admin.site.register(Subscription, SubscriptionAdmin)
admin.site.register(Feedback, FeedbackAdmin)

