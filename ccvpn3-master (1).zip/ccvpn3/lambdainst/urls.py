from django.urls import path
from django.contrib.auth import views as auth_views
import django_lcore

from . import views

app_name = 'lambdainst'

urlpatterns = [
    path('login', auth_views.LoginView.as_view(), name='login'),
    path('discourse_login', views.discourse_login, name='discourse_login'),
    path('logout', views.logout, name='logout'),
    path('signup', views.signup, name='signup'),

    path('settings', views.settings),
    path('config', views.config),
    path('config_dl', django_lcore.views.openvpn_dl),
    path('wireguard', views.wireguard),
    path('wireguard/new', views.wireguard_new, name='wireguard_new'),
    path('logs', views.logs),
    path('gift_code', views.gift_code),
    path('trial', views.trial),
    path('', views.index, name='index'),
]
