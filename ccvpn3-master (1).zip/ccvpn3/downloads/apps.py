from django.apps import AppConfig


class DownloadsConfig(AppConfig):
    name = 'downloads'
