from django import template
from django.utils.html import format_html
from downloads.models import Version, Platform
from django.utils.translation import ugettext as _

register = template.Library()

BUTTON_HTML = """
<a class="pure-button pure-button-primary download-button" href="{url}">{title}</a>
[(sig)]({url}.asc)
"""

@register.simple_tag
def download_button(download, platform):
    latest = Version.objects.get_latest(download, platform)
    if not latest:
        return format_html("\ufffc")

    title = _("Download {} v{}").format(latest.download, latest.version)
    return format_html(BUTTON_HTML.strip(), url=latest.url, title=title)

