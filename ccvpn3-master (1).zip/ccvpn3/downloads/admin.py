from django.contrib import admin
from .models import Download, Platform, Version

# Register your models here.

class VersionAdmin(admin.ModelAdmin):
    list_display = ('download', 'platform', 'version', 'latest', 'available')
    list_filter = ('download__name', 'platform__name', 'latest', 'available')

admin.site.register(Download)
admin.site.register(Platform)
admin.site.register(Version, VersionAdmin)
